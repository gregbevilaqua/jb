<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'Z00I3Cp4XQfzQ9VsuChZzEfJE');
    define('CONSUMER_SECRET', 'RA5zYSWXKrd7J82Ywi7sY7eilxLQa9esxGWvSWYoOJAqkWb45V');

    // User Access Token
    define('ACCESS_TOKEN', '2549249701-1Nuart0RHEEOtFdNMlYbA0qQQWMGPNb7j0aCFV5');
    define('ACCESS_SECRET', 'ULMA1l29A8lcNn5NOdGzatJb16LnVErEhr1rKfivyyBcM');