<?php

echo "C---splithere---";

?>
