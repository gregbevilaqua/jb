<?php
header("Location: http://www.uolhost.uol.com.br/avisos-plataforma/aguardando-publicacao.html"); /* Redirect browser */
exit();
?>
