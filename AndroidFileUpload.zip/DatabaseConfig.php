<?php
//Define your host here.
$HostName = "localhost";

//Define your database username here.
$HostUser = "petgame_user";

//Define your database password here.
$HostPass = "clara2018";

//Define your database name here.
$DatabaseName = "petgame_base";

?>